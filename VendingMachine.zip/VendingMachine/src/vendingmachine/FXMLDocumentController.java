/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vendingmachine;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author moell
 */
public class FXMLDocumentController implements Initializable {
    float totalMoney = 0;
    int totalQuarters = 0;
    int totalDimes = 0;
    int totalNickels = 0;
    float weight = 0;
    float diameter = 0;
    
    static float quarterWeight = (float) 5.67;
    static float dimeWeight = (float) 2.268;
    static float nickelWeight = 5;
    static float quarterDiameter = (float) 0.955;
    static float dimeDiameter = (float) 0.705;
    static float nickelDiameter = (float) 0.835;
    
    @FXML
    private Label display;
    @FXML
    private Label display1;
    @FXML
    private Label returnslot;
    
    public TextField weightBox;
    public TextField diameterBox;
    
    
    public ComboBox<String> CoinSlot;
    ObservableList<String> coins = FXCollections.observableArrayList("penny", "nickel", "dime", "quarter");
    
    private static DecimalFormat df = new DecimalFormat("0.00");
    
    //UNIT TEST 1 - Insert Quarter, Dime, Nickel, and Penny. Eject all coins
    //Expected outcome - Machine accepts Quarter, Dime, and Nickel. Penny is rejected.
    //   Quarter, Dime, and Nickel returned.
    public void test1(){
         weight = (float) 5.67;
         diameter = (float) 0.955;
         newCoin();
         weight = (float) 2.268;
         diameter = (float) 0.705;
         newCoin();
         weight = (float) 5;
         diameter = (float) 0.835;
         newCoin();
         weight = (float) 2.5;
         diameter = (float) 0.75;
         newCoin();
         
         returnCoins();
         
    }
    
    //UNIT TEST 2 - Insert 4 Quarters. Purchase Cola.
    //Expected Outcome - 4 Quarters Accepted. Cola successfully dispensed
    public void test2(){
        for(int i = 0; i < 4; i++){
            weight = (float) 5.67;
            diameter = (float) 0.955;
            newCoin();
        }
        dispenseCola();
    }
    
    //UNIT TEST 3 - Insert 6 Dimes. Purchase Chips. Eject Coins.
    //Expected Outcome - 6 Dimes Accepted. Chips successfully dispensed. Dime returned.
    public void test3(){
        for(int i = 0; i < 6; i++){
            weight = (float) 2.268;
            diameter = (float) 0.705;
            newCoin();
        }
        dispenseChips();
        returnCoins();
    }
    
    //UNIT TEST 4 = Purchase Candy. Insert Quarter. Purchase Candy. Insert two more quarters.
    //  Purchase Candy. Eject Coins. Insert dime and nickel. Eject Coins.
    //Expected Outcome: Candy purchase unsuccessful. Quarter Accepted. Candy purchase unsuccessful
    //  Two more quarters accepted. Candy purchase successful. Coin return unsuccessful.
    //  Dime accepted. Nickel Accepted. Quarter returned.
    public void test4(){
        dispenseCandy();
        weight = (float) 5.67;
        diameter = (float) 0.955;
        newCoin();
        dispenseCandy();
        for(int i = 0; i < 2; i++){
            weight = (float) 5.67;
            diameter = (float) 0.955;
            newCoin();
        }
        dispenseCandy();
        returnCoins();
        weight = (float) 2.268;
        diameter = (float) 0.705;
        newCoin();
        weight = (float) 5;
        diameter = (float) 0.835;
        newCoin();
        returnCoins();
    }
   
    
    @FXML
    public void clickCola(ActionEvent event) {
        dispenseCola();
        
    }
    
    public void dispenseCola(){
        if(totalMoney >= 1){
            totalMoney -= 1;
            returnslot.setText("Cola Dispensed");
            display.setText("Amount inserted: " + df.format(totalMoney));
            display1.setText("THANK YOU");
            System.out.println("Cola successfully dispensed");
            
        } else {
            display.setText("Insert more coins");
            System.out.println("Cola not dispensed");
        }
    }
    @FXML
    public void clickChips(ActionEvent event) {
        dispenseChips();
        
    }
    
    public void dispenseChips(){
        if(totalMoney >= 0.50){
            totalMoney -= 0.50;
            returnslot.setText("Chips Dispensed");
            display.setText("Amount inserted: " + df.format(totalMoney));
            display1.setText("THANK YOU");
            System.out.println("Chips successfully dispensed");
            
        } else {
            display.setText("Insert more coins");
            System.out.println("Chips not dispensed");
        }
    }
    @FXML
    public void clickCandy(ActionEvent event) throws InterruptedException {
        dispenseCandy();
        
    }
    
    public void dispenseCandy(){
        if(totalMoney >= 0.65){
            totalMoney -= 0.65;
            returnslot.setText("Candy Dispensed");
            display.setText("Amount inserted: " + df.format(totalMoney));
            display1.setText("THANK YOU");
            System.out.println("Candy successfully dispensed");
        
        } else {
            display.setText("Insert more coins");
            System.out.println("Candy not dispensed");
        }
    }
    
    public void insertCoin(ActionEvent event){
        weight = Float.parseFloat(weightBox.getText());
        diameter = Float.parseFloat(diameterBox.getText());
        newCoin();
    }
    
    public void newCoin() {
        returnslot.setText("");
        display1.setText("");
        
        
        if(Math.abs(weight - quarterWeight) < 1e-4 && Math.abs(diameter - quarterDiameter) < 1e-4){
            totalMoney += 0.25;
            totalQuarters += 1;
            System.out.println("Quarter Accepted");
        }else if(Math.abs(weight - dimeWeight) < 1e-4 && Math.abs(diameter - dimeDiameter) < 1e-4){
            totalMoney += 0.10;
            totalDimes += 1;
            System.out.println("Dime Accepted");
        }else if(Math.abs(weight - nickelWeight) < 1e-4 && Math.abs(diameter - nickelDiameter) < 1e-4){
            totalMoney += 0.05;
            totalNickels += 1;
            System.out.println("Nickel Accepted");
        }else{
            returnslot.setText("Coin Returned");
            System.out.println("Coin Rejected. Weight:" + weight + " Diameter:" + diameter);
            
        }
//        String coin = CoinSlot.getValue();
//        
//        
//        switch (coin) {
//            case "quarter": totalMoney += 0.25;
//            totalQuarters += 1;
//            break;
//            case "dime": totalMoney += 0.10;
//            totalDimes += 1;
//            break;
//            case "nickel": totalMoney += 0.05;
//            totalNickels += 1;
//            break;
//            default: returnslot.setText("Coin Returned");
//            break;
//        }
        display.setText("Amount inserted: " + df.format(totalMoney));  
    }
    
    public void coinEject(ActionEvent event) {
        returnCoins();
    }
    public void returnCoins(){
    if(totalMoney > 0){
            System.out.println("Amount to be returned " + df.format(totalMoney));
            System.out.println("Total coins in machine:");
            System.out.println("Quarters: " + totalQuarters);
            System.out.println("Dimes: " + totalDimes);
            System.out.println("Nickels: " + totalNickels);
            while(totalMoney >= 0.25 && totalQuarters > 0){
                totalQuarters -= 1;
                totalMoney -= 0.25;
                returnslot.setText("Change returned");
                display.setText("Amount inserted: " + df.format(totalMoney));
                System.out.println("Quarter returned");

            }while(totalMoney >= 0.10 && totalDimes > 0){
                totalDimes -= 1;
                totalMoney -= 0.10;
                returnslot.setText("Change returned");
                display.setText("Amount inserted: " + df.format(totalMoney));
                System.out.println("Dime returned");

            }while(totalMoney >= 0.05 && totalNickels > 0){
                totalNickels -= 1;
                totalMoney -= 0.05;
                returnslot.setText("Change returned");
                display.setText("Amount inserted: " + df.format(totalMoney));
                System.out.println("Nickel returned");

            }
            if(totalMoney > 0.04){
                returnslot.setText("Insufficient coins");
                System.out.println("Insufficient coins in machine to return");
            }
            
            System.out.println("Updated total coins in machine:");
            System.out.println("Quarters: " + totalQuarters);
            System.out.println("Dimes: " + totalDimes);
            System.out.println("Nickels: " + totalNickels);
        }
}
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        display.setText("INSERT COIN");
        if(totalDimes < 1 || totalNickels < 1){
            display1.setText("EXACT CHANGE ONLY");
        }
        CoinSlot.setItems(coins);
        returnslot.setText("");
        
//        test1();
//        test2();
//        test3();
//        test4();
        
        
    }    

//    private void restart()  {
//
//        display.setText("INSERT COIN");
//        if(totalDimes < 1 || totalNickels < 1){
//            display1.setText("EXACT CHANGE ONLY");
//        }
//        CoinSlot.setItems(coins);
//        returnslot.setText("");
//    }
    
}
