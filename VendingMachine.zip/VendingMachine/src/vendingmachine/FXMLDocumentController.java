/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vendingmachine;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

/**
 *
 * @author moell
 */
public class FXMLDocumentController implements Initializable {
    float totalMoney = 0;
    int totalQuarters = 0;
    int totalDimes = 0;
    int totalNickels = 0;
    @FXML
    private Label display;
    @FXML
    private Label display1;
    @FXML
    private Label returnslot;
    
    
    public ComboBox<String> CoinSlot;
    ObservableList<String> coins = FXCollections.observableArrayList("penny", "nickel", "dime", "quarter");
    
    private static DecimalFormat df = new DecimalFormat("0.00");
    
    @FXML
    public void clickCola(ActionEvent event) {
        if(totalMoney >= 1){
            totalMoney -= 1;
            returnslot.setText("Cola Dispensed");
            display.setText("Amount inserted: " + df.format(totalMoney));
            display1.setText("THANK YOU");
            
        } else {
            display.setText("Insert more coins");
        }
        
    }
    @FXML
    public void clickChips(ActionEvent event) {
        if(totalMoney >= 0.50){
            totalMoney -= 0.50;
            returnslot.setText("Chips Dispensed");
            display.setText("Amount inserted: " + df.format(totalMoney));
            display1.setText("THANK YOU");
            
        } else {
            display.setText("Insert more coins");
        }
        
    }
    @FXML
    public void clickCandy(ActionEvent event) throws InterruptedException {
        if(totalMoney >= 0.65){
            totalMoney -= 0.65;
            returnslot.setText("Candy Dispensed");
            display.setText("Amount inserted: " + df.format(totalMoney));
            display1.setText("THANK YOU");
        
        } else {
            display.setText("Insert more coins");
        }
        
    }
    public void insertCoin(ActionEvent event){
        
        String coin = CoinSlot.getValue();
        returnslot.setText("");
        display1.setText("");
        
        switch (coin) {
            case "quarter": totalMoney += 0.25;
            totalQuarters += 1;
            break;
            case "dime": totalMoney += 0.10;
            totalDimes += 1;
            break;
            case "nickel": totalMoney += 0.05;
            totalNickels += 1;
            break;
            default: returnslot.setText("Coin Returned");
            break;
        }
        display.setText("Amount inserted: " + df.format(totalMoney));  
        
    }
    
    public void coinEject(ActionEvent event) {
        if(totalMoney > 0){
            System.out.println("Amount to be returned " + df.format(totalMoney));
            System.out.println("Total coins in machine:");
            System.out.println("Quarters: " + totalQuarters);
            System.out.println("Dines: " + totalDimes);
            System.out.println("Nickels: " + totalNickels);
            while(totalMoney >= 0.25 && totalQuarters > 0){
                totalQuarters -= 1;
                totalMoney -= 0.25;
                returnslot.setText("Change returned");
                display.setText("Amount inserted: " + df.format(totalMoney));

            }while(totalMoney >= 0.10 && totalDimes > 0){
                totalDimes -= 1;
                totalMoney -= 0.10;
                returnslot.setText("Change returned");
                display.setText("Amount inserted: " + df.format(totalMoney));

            }while(totalMoney >= 0.05 && totalNickels > 0){
                totalNickels -= 1;
                totalMoney -= 0.05;
                returnslot.setText("Change returned");
                display.setText("Amount inserted: " + df.format(totalMoney));

            }
            if(totalMoney > 0.04){
                returnslot.setText("Insufficient coins");
            }
            System.out.println("Coins successfully returned");
            System.out.println("Updated total coins in machine:");
            System.out.println("Quarters: " + totalQuarters);
            System.out.println("Dines: " + totalDimes);
            System.out.println("Nickels: " + totalNickels);
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        display.setText("INSERT COIN");
        if(totalDimes < 1 || totalNickels < 1){
            display1.setText("EXACT CHANGE ONLY");
        }
        CoinSlot.setItems(coins);
        returnslot.setText("");
        
        
        
    }    

    private void restart()  {

        display.setText("INSERT COIN");
        if(totalDimes < 1 || totalNickels < 1){
            display1.setText("EXACT CHANGE ONLY");
        }
        CoinSlot.setItems(coins);
        returnslot.setText("");
    }
    
}
